#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import scipy
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.multicomp import MultiComparison
import seaborn as sns


# In[2]:


YouTube = pd.read_csv("C:/Users/Lenovo/OneDrive/Desktop/Data-Science-Program/DATASETS/YouTubeChannels.csv")


# In[9]:


YouTube.head()


# In[ ]:


YouTube1 = YouTube[['Gr2de', 'Video views']]


# In[ ]:


YouTube1.head()


# In[ ]:


YouTube1.info()


# In[ ]:


def recode (series): 
    if series == 0: 
        return "A plus plus"
    if series == 1: 
        return "A plus"
    if series == 2: 
        return "A"
    if series == 3:
        return "B plus"

YouTube1['GradeR'] = YouTube1['Gr2de'].apply(recode)


# In[ ]:


sns.distplot(YouTube1['Video views'])


# In[ ]:


YouTube1['VideoViewsSQRT'] = np.sqrt(YouTube1['Video views'])


# In[ ]:


YouTube1.head()


# In[ ]:


sns.distplot(YouTube1['VideoViewsSQRT'])


# #### Looking much better, but try a log transformation just in case

# In[ ]:


YouTube1['VideoViewsLOG'] = np.log(YouTube1['Video views'])


# In[ ]:


YouTube1.head()


# In[ ]:


sns.distplot(YouTube1['VideoViewsLOG'])


# ### looks mirrored imaged, but is slightly more normal. So stick with LOG

# ## Homogeneity of Variance

# In[ ]:


scipy.stats.bartlett(YouTube1['VideoViewsLOG'], YouTube1['Gr2de'])


# ### Does not meet the assumption of homogeneity of variance. Variance is unequal!

# # Run the Analysis
# 

# In[ ]:


YouTubeNatural.dropna(inplace=True)


# In[ ]:


stats.f_oneway(YouTube1['VideoViewsLOG'][YouTube1['GradeR']=='A plus plus'],
                   YouTube1['VideoViewsLOG'][YouTube1['GradeR']=='A plus'],
               YouTube1['VideoViewsLOG'][YouTube1['GradeR']=='A'],
               YouTube1['VideoViewsLOG'][YouTube1['GradeR']=='B plus'])


# ## Post Hoc

# In[ ]:


postHoc = MultiComparison(YouTube1['VideoViewsLOG'], YouTube1['Gr2de'])
postHocResults = postHoc.tukeyhsd()
print(postHocResults)


# # Conclusions

# In[ ]:


YouTube1.groupby('GradeR').mean()


# ## All grades of YouTube videos significantly differed from each other, with the higher ratings seeming to get the most reviews.
