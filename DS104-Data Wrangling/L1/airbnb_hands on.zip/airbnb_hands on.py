import pandas as pd
airbnb=pd.read.csv("C:/Users/Lenovo/Desktop/Data-Science-Program/DATASETS/airbnb_test_users.csv")
airbnb.head()
age.groupby('age')['first_browser'].average()
signup_flow.groupby('signup_flow')['first_device_type'].sum()
airbnb_sample_submission=pd.read.csv("C:/Users/Lenovo/Desktop/Data-Science-Program/DATASETS/airbnb_sample_submission.csv")
airbnb.pd.merge('airdnd_sample_submission=$country')
airbnb_users=pd.read.csv("C:/Users/Lenovo/Desktop/Data-Science-Program/DATASETS/airbnb_users.csv")
airbnb_users.head()
airbnb=pd.concat([airbnb_users])

